# Niketan Jatwa — Portfolio Web App

A modern responsive portfolio website built with pure HTML, CSS and JavaScript.

## Run
1. Extract the ZIP.
2. Open `index.html` in a browser.

For VS Code, you can install/use Live Server and open `index.html`.

## Customize before publishing
- Replace `your-email@example.com` in `index.html` with your real email.
- Add your GitHub URL.
- Add project demo/repository links.
- Replace/add your own profile photo if desired.
- Update education/skills as they change.

## Files
- index.html — page structure/content
- style.css — responsive design and animations
- script.js — menu, theme toggle and scroll reveal
